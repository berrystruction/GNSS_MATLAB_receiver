function [ varianceMtx ] = PseudoVarianceComputation(cumulativepseudo,pseudoranges,SQI)
% Variance estimation of the pseudoranges

end